package TP1;

class Couple{
	Arbre a;
	Etat e;
	
	public Couple(Arbre a, Etat e) {
		this.a=a;
		this.e=e;
	}
}