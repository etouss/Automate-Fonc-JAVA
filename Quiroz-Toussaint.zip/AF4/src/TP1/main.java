package TP1;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Arbre test1 = Arbre.lirePostfixe("abab.+*.b*abb.+.+ijk+..");
		System.out.println(test1);
		Automate auto2 = test1.toAutomate();
		//System.out.println(auto2);
		Moore moore = new Moore();
		auto2 = moore.miniMoore(auto2);
		Residuel resi1 = new Residuel();
		Automate auto1 = resi1.miniResiduel(test1);
		System.out.println(auto1);
		System.out.println(auto2);
		//System.out.println(auto1.egaliteMini(auto2));
		*/
		
		
		Interface inter = new Interface();
		
	}
}
